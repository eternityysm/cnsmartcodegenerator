﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class _Default : BasePage
{

    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        this.Page.Title = "HP Web Application Style";
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
        }
    }


    protected void btnQuery_OnClick(object sender, EventArgs e)
    {
    }
}
