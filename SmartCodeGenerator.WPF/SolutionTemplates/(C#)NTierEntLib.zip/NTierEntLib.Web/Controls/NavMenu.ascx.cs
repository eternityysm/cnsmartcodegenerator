﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Collections;
using System.Xml;
using System.Data;

public partial class Controls_NavMenu : BaseControl
{
    protected DataTable NavMenuTable
    {
        get
        {
            if (this.Cache["NavMenuTable"] == null)
            {
                this.Cache.Insert("NavMenuTable",GetXmlData()); 
            }
            return this.Cache["NavMenuTable"] as DataTable;
        }
        set
        {
            ViewState["NavMenuTable"] = value;
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);
    }
    public override void RenderControl(HtmlTextWriter writer)
    {
        //SideMenu(writer);
        TopMenu(writer);
    }

    protected void SideMenu(HtmlTextWriter writer)
    {
        //StringBuilder s = new StringBuilder();
        //s.Append(@"<div class='easyui-accordion' fit='true' border='false' >");
        //List<Role> menuGroupList = new List<Role>();// PermissionLogic.GetUserRoleMenus(this.CurrentUser.UserID);
        //if (menuGroupList != null)
        //{
        //    foreach (Role r in menuGroupList)
        //    {
        //        s.Append(@"<div  icon='icon-MenuGroup'  style='overflow:auto;  padding-left:8px;'");
        //        s.Append(@" title=" + r.Title + " >");
        //        List<Permission> iList = PermissionLogic.GetUserRolePermissionMenus(this.CurrentUser.UserID, r.RoleID);
        //        foreach (Permission p in iList)
        //        {
        //            s.Append("<li class='MenuLi'><a href='" + p.CurPath + "'  target='ifrBody' >");
        //            s.Append(p.Title);
        //            s.Append(@"</a></li>");
        //        }
        //        s.Append(@"</div>");
        //    }

        //}
        //s.Append(@"</div>");
        //writer.Write(s.ToString());
    }
    protected void TopMenu(HtmlTextWriter writer)
    {
        StringBuilder s = new StringBuilder();
        s.Append(@"<div style='padding:5px;width:100%;' >"); 
        StringBuilder mlistid = new StringBuilder();
        DataRow[] topMenus = this.GetTopData();

        if (topMenus != null)
        {
            foreach (DataRow r in topMenus)
            {
                DataRow[] subMenus = this.GetSubData(r["Code"].ToString());
                if (subMenus != null && subMenus.Length > 0)
                {
                    s.Append(@"<a href='javascript:void(0)' id='mb" + r["Code"].ToString() + "'  class='easyui-menubutton' menu='#mm" + r["Code"].ToString() + "'  icon='icon-MenuGroup'  >");
                    s.Append(r["title"].ToString());
                    s.Append(@"</a>");
                }
                else
                {
                    s.Append(@"<a href='" + GetAppPath() + @"/" + r["url"].ToString() + "' id='mb" + r["Code"].ToString() + "'  class='easyui-menubutton'  icon='icon-MenuGroup'  >");
                    s.Append(r["title"].ToString());
                    s.Append(@"</a>");
                }
                mlistid.Append(@"#" + r["Code"].ToString() + ",");
            }
            s.Append(@"</div>");
            foreach (DataRow r in topMenus)
            {
                DataRow[] subMenus = this.GetSubData(r["Code"].ToString());
                if (subMenus != null && subMenus.Length > 0)
                {
                    s.Append(@"<div id='mm" + r["Code"].ToString() + "' style='width:150px;'>");

                    foreach (DataRow sm in subMenus)
                    {
                        s.Append(@"<div icon='icon-redo' onclick=" + "\"" + "OpenMenuLink('" + GetAppPath() + @"/" + sm["url"].ToString() + "')" + "\"" + " >");
                        s.Append(sm["title"].ToString());
                        s.Append(@"</div>");
                    }
                    s.Append(@"</div>");
                }
            }
        }
        s.Append(@"</div>");
        string tmp = mlistid.ToString();
        this.Page.ClientScript.RegisterClientScriptBlock(this.Page.GetType(), "TopMenu", "<script>$(function(){ $('" + tmp.Substring(0, tmp.Length - 1) + "').menubutton({ plain:true});});</script>");
        writer.Write(s.ToString());
    }

    protected DataTable GetXmlData()
    {
        DataSet ds = new DataSet();
        ds.ReadXml(HttpContext.Current.Server.MapPath("~/") + @"\App_Data\NavMenuXMLFile.xml");
        return ds.Tables[0];
    }
    protected DataRow[] GetTopData()
    {
        return this.NavMenuTable.Select(" ParentCode='' ", "Code");
    }
    protected DataRow[] GetSubData(string prarenCode)
    {
        return this.NavMenuTable.Select(" ParentCode='" + prarenCode + "' ", "Code");
    }
}